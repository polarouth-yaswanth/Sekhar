package com.odcw.outh2.githubandgoogle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GithubandgoogleApplicationTests {

	@Test
	void contextLoads() {
	}

}
