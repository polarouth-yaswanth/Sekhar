/* import React from 'react';
import Login from './components/pages/Login';
import SignUp from './components/pages/SignUp';

test("login form should be in th document", () => {
  const Component = render(<SignUp/>);
  const emailInputNode = Component.getByLabelText("email:");
  expect(emailInputNode.getAttribute("name")).toBe("email");
})


 */