import React from 'react'

const Showcase = () => {

    return(
        <section className='showcase'>
        <div>
            <h1 className='overlay' >Welcome To Eagle</h1>
            <p>Fly like a Eagle</p>    
        </div>
        </section>
    )
}

export default Showcase;